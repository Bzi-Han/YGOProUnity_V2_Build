--ハーピィ・レディ三姉妹
function c12206212.initial_effect(c)
	c:EnableReviveLimit()
end
